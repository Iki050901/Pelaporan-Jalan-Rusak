-- AlterTable
ALTER TABLE `reports` ADD COLUMN `is_delete` BOOLEAN NOT NULL DEFAULT false;
