-- AlterTable
ALTER TABLE `reports` MODIFY `notes` TINYTEXT NULL;
