-- AlterTable
ALTER TABLE `users` MODIFY `is_delete` BOOLEAN NOT NULL DEFAULT false;
